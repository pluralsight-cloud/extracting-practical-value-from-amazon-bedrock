# Lab 4: Observing Cost and Variability with Controlled Inputs

This lab uses a fixed prompt and a fixed Amazon Bedrock inference configuration to observe normal response variation, token usage, and latency across repeated invocations.

## Files

- `prompt.txt` - The controlled prompt used for each model invocation.
- `invoke_bedrock.py` - Python script that invokes Amazon Bedrock multiple times using the same configuration.
- `results.csv` - Output file where invocation metrics and response summaries are recorded.
- `README.md` - This file.

## Fixed inference configuration

The script uses the following configuration:

```python
INFERENCE_CONFIG = {
    "maxTokens": 300,
    "temperature": 0.2,
    "topP": 0.9,
}
```

These values intentionally remain unchanged during the lab so you can observe normal variability under controlled conditions.

## Run the lab

From this folder, run:

```bash
python3 invoke_bedrock.py
```

The script performs three invocations using the same prompt and the same inference configuration.

## Review the results

After the script completes, open `results.csv`.

Compare:

- Input token count
- Output token count
- Total token count
- Latency
- First sentence
- Response text

## What to observe

You should notice that:

- The prompt remains the same.
- The inference settings remain the same.
- Responses may still vary slightly.
- Output token counts may vary.
- Latency may vary.

## Key takeaway

Controlled inputs and fixed inference settings make normal variability observable. This helps teams distinguish expected probabilistic behavior from unusual cost, stability, or response-pattern changes.
