#!/usr/bin/env python3
"""
Lab 4: Observing Cost and Variability with Controlled Inputs

Runs repeated Amazon Bedrock invocations using the same prompt and the same
fixed inference configuration. Results are appended to results.csv so you can
compare token usage, latency, and response variation across runs.
"""

import csv
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import boto3
from botocore.exceptions import BotoCoreError, ClientError

REGION = "us-east-1"
MODEL_ID = "amazon.nova-pro-v1:0"

INFERENCE_CONFIG = {
    "maxTokens": 300,
    "temperature": 0.2,
    "topP": 0.9,
}

PROMPT_FILE = Path("prompt.txt")
RESULTS_FILE = Path("results.csv")
RUN_COUNT = 3


def load_prompt():
    if not PROMPT_FILE.exists():
        raise FileNotFoundError(f"Missing prompt file: {PROMPT_FILE}")
    return PROMPT_FILE.read_text(encoding="utf-8").strip()


def extract_text(response):
    content = response.get("output", {}).get("message", {}).get("content", [])
    text_parts = [item.get("text", "") for item in content if "text" in item]
    return "\n".join(text_parts).strip()


def get_usage(response):
    usage = response.get("usage", {})
    return {
        "input_tokens": usage.get("inputTokens", ""),
        "output_tokens": usage.get("outputTokens", ""),
        "total_tokens": usage.get("totalTokens", ""),
    }


def ensure_results_file():
    if RESULTS_FILE.exists():
        return
    with RESULTS_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            "timestamp_utc",
            "run_number",
            "model_id",
            "max_tokens",
            "temperature",
            "top_p",
            "input_tokens",
            "output_tokens",
            "total_tokens",
            "latency_ms",
            "first_sentence",
            "response_text",
        ])


def first_sentence(text):
    normalized = " ".join(text.split())
    if "." in normalized:
        return normalized.split(".", 1)[0] + "."
    return normalized[:160]


def append_result(run_number, response, latency_ms):
    text = extract_text(response)
    usage = get_usage(response)
    with RESULTS_FILE.open("a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            datetime.now(timezone.utc).isoformat(),
            run_number,
            MODEL_ID,
            INFERENCE_CONFIG["maxTokens"],
            INFERENCE_CONFIG["temperature"],
            INFERENCE_CONFIG["topP"],
            usage["input_tokens"],
            usage["output_tokens"],
            usage["total_tokens"],
            latency_ms,
            first_sentence(text),
            text,
        ])


def invoke_model(client, prompt):
    start = time.perf_counter()
    response = client.converse(
        modelId=MODEL_ID,
        messages=[
            {
                "role": "user",
                "content": [{"text": prompt}],
            }
        ],
        inferenceConfig=INFERENCE_CONFIG,
    )
    elapsed_ms = round((time.perf_counter() - start) * 1000)
    return response, elapsed_ms


def main():
    prompt = load_prompt()
    ensure_results_file()
    client = boto3.client("bedrock-runtime", region_name=REGION)

    print("Lab 4: Controlled Bedrock Invocations")
    print("------------------------------------")
    print(f"Model: {MODEL_ID}")
    print(f"Region: {REGION}")
    print(f"Prompt file: {PROMPT_FILE}")
    print(f"Results file: {RESULTS_FILE}")
    print(f"Fixed configuration: {json.dumps(INFERENCE_CONFIG)}")
    print()

    for run_number in range(1, RUN_COUNT + 1):
        print(f"Running invocation {run_number} of {RUN_COUNT}...")
        try:
            response, latency_ms = invoke_model(client, prompt)
        except (BotoCoreError, ClientError) as error:
            print(f"Invocation failed: {error}")
            raise

        append_result(run_number, response, latency_ms)
        usage = get_usage(response)
        print(f"  Input tokens:  {usage['input_tokens']}")
        print(f"  Output tokens: {usage['output_tokens']}")
        print(f"  Total tokens:  {usage['total_tokens']}")
        print(f"  Latency:       {latency_ms} ms")
        print(f"  First sentence: {first_sentence(extract_text(response))}")
        print()

    print("Done. Review results.csv to compare token usage, latency, and response variation.")


if __name__ == "__main__":
    main()
